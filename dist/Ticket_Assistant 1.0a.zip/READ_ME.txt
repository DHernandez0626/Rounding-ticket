This program is made to automate creation of multiple ticket with many similar parameters. 
This is intended to increase work flow productivity by minimizing the amount of time spent creating tickets manually if they all contain similar information.

This workflow was intended specifically for HCA FLORIDA KENDALL's IT team but this may work for multiple facilities and could potentially free users from having to spend a lot of time creating tickets.

-------------------------------------------------------------------


PLEASE ADHERE TO THE FOLLOWING INSTRUCTIONS TO EFFECTIVELY USE THIS TOOL:

Report by: should include the persons name or 3/4 exactly as it should be on service central. If it is misspelled it wont work and may interrupt the script from executing correctly

Hospital: Should include the hospital name exactly as it appears in service central for example HCA FLORIDA KENDALL HOSPITAL is the correct name in service central for that hospital.

---------------------------------------------------
the tickets created will all use the same short description but will prefix the ticket with the issue type and device name

for example if you had a ticket for a pc KRMCTESTCW01

the ticket will appear as

KRMCTESTCW01- PC - Short description of issue

########################################################################################################

IF YOU NEED TO ABORT PROGRAM PRESS ESC OR MOVE YOUR MOUSE TO THE TOP LEFT CORNER OF YOUR MONITOR UNTIL AN ALERT WINDOW APPEARS

########################################################################################################


any questions in regard to this program please reach out to me on Webex Danny Hernandez or via email Danny.Hernandez3@hcahealthcare.com